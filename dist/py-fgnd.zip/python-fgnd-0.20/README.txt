

The FGND package provides the first fully generalized normal distribution, generalized for skewness and kurtosis.

System Requirements:
Python installation with the Python packages
- Numpy
- Scipy
- Sympy
- Pandas

- sys
- os
- time.

These -- in case -- can be easierst installed as follows: 1. Installling Python Packkages PIP. 2. Typing "pip3 install numpy" (Windows: "pip install numpy") in a terminal window.  [In case no internet access, the last three ones (sys, os, time) can be relinguished, when removing on some "luxury parts" from the program.]

Or you can install the Anaconda Numerical Python Distribution, that already includes them all. (Which however, is a commercial non-fully-open-source project.)


#############################################################################################################################


The FGND package is distributed as a classical "Python source code distribution". To install the package proceed as following:

1. Download python-fgnd-vx.xx.zip and unzip python-fgnd-vx.xx.zip. (Which you have already done, when reading this README.txt) 

2. Check, if the subdirectory "fgnd" is populated with files. Sometimes the archiver programm is misconfigured this way, that it unzips all files to the top directory. If this has happened, you need to move some files back to the folder "fgnd", so that their location matches the listing in "MANIFEST". Otherwise, everything is fine, here. 

3. Open a terminal window (Windows: power shell) and change to the directory with the unzipped python-fgnd-vx.xx files, e.g. typing "cd xxx/.../xxx/python-fgnd-vx.xx"

Execute with adminstrator/ root privileges:
4a. Linux terminal: "sudo python3 setup.py install"
4b. Windows admin-powershell: "python setup.py install".
4c. OS-X: "python setup.py install" or "python3 setup.py install". [The author does not know exactly.]

The package will be installed under the operating system's standard path for 3rd party Python packages into the directoy "fgnd".

Check the succesfull install by typing "python3 import fgnd" (Windows: "python import fgnd"). If successfull, "FGND Setup Check SUCCESSFULL" and some other check routines will be printed.

That's all. 


Now, you can run the Generation and Re-Identification Test by typing in the terminal window: 
1. python3 (Windows: python)
2. import fgnd.genreidtest 


To apply the package in your own programs you have to include the line 
"import fgnd.modul as xxx" 
in the beginning of your own python program. 


#############################################################################################################################


The package can also get run without installation from local. Which does not make use of faster byte-compiled (.pyc) Python modules.  

Preliminary, the prgram "genreidtest.py" needs a modification. The line 
"import fgnd.modul as modul"
has to be exchanged by 
"import modul"
, which is already prepared as outcommented line. The other modules/ programs do not require a code modification.


Now, you can run the Generation and Re-Identification Test by typing in the terminal window: 
1. cd xxx/.../xxx/python-fgnd-x.xx/fgnd
2. python3 genreidtest.py (Windows: python genreidtest.py)


To apply the package in your own programs from local you have to include the line 
"import modul" 
in the beginning of your own python program. 
[Your own python program importing FGND from local has -- for some Dutch reasons -- to be located in the folder python-fgnd-x.xx/fgnd/. Respectively, the author does not know more comfortable.]


#############################################################################################################################


For in case further installation assistance consult an internet search engine with the search terms:
- "How to install Python on Windows/ Linux/ OS-X"
- "How install a python source code distribution"
- "How to alternate the installation path of a python source code distribution"


#############################################################################################################################


A statistical introduction into the fully generalized normal distribution is provided at "www.quantsareus.net/hs/publ/introducing_a_fully_generalized_normal_distribution.pdf"


