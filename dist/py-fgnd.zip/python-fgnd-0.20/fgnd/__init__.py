

#####! /usr/bin/env python3


def version_changes():
	"""
	Version changes from V0.17 to V0.20:
	- Creation
	"""
	pass


#####################################################################################

import fgnd.modul as modul
